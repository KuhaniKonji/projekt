<div>Prijavljeni ste kot Admin (<a href="php/odjava.php">Odjava</a>) </div>
<div>Copyright 	&copy; Teo 2021 </div>
