<span class="logo"><a href="index.php">Logo</a> </span>
<div class="nav">
  <span> <a href="predmeti.php">Predmeti</a> </span>
  <span> <a href="naloge.php">Naloge</a> </span>
  <span> <a href="ucenci.php">Učenci</a> </span>
</div>
<span class="odjava"><a href="php/odjava.php">Odjava</a> </span>
