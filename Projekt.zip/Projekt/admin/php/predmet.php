<?php
$sql_predmet="SELECT * FROM predmeti where id_predmeta='$id_predmeta'";
$res_predmet=mysqli_query($con, $sql_predmet);
 ?>
