<span class="logo"><a href="index.php"><img src="../Slike/OIP.jpg" alt=""></a></span>
<div class="nav">
  <span> <a href="predmeti.php">Predmeti</a> </span>
  <span> <a href="naloge.php">Naloge</a> </span>
  <span> <a href="redovalnica.php">Redovalnica</a> </span>
  <span> <a href="ucitelji.php">Učitelji</a> </span>
</div>
<span class="profil"><a href="profil.php"><img src="../Slike/user-fill.svg" alt=""></a><span class="odjava"><a href="php/odjava.php"><img src="../Slike/logout-box-fill.svg" alt=""></a> </span></span>

