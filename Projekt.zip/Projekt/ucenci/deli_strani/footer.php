<div class="noga">Prijavljeni ste kot <?php echo $ime_ucenca; ?> (<a href="php/odjava.php">Odjava</a>) </div>
<div>Copyright 	&copy; Big Boss 2024 </div>
