<?php
$color1="#212b38";
$color2="#37465b";
$color3="#06c6ab";
$color4="#726eff";
$color5="#5affe7";
$color6="#ccdeff";
$color7="#423ecf";

 ?>
