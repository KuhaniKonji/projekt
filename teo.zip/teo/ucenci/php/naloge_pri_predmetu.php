<?php
$sql_naloge_pri_predmetu="select * from naloge where id_predmeta='$id_predmeta'";
$res_naloge_pri_predmetu=mysqli_query($con, $sql_naloge_pri_predmetu);

 ?>
