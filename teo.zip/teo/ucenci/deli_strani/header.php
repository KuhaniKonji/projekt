<span class="logo"><a href="index.php">Logo</a> </span>
<div class="nav">
  <span> <a href="predmeti.php">Predmeti</a> </span>
  <span> <a href="naloge.php">Naloge</a> </span>
  <span> <a href="redovalnica.php">Redovalnica</a> </span>
  <span> <a href="ucitelji.php">Učitelji</a> </span>
</div>
<span class="odjava"><a href="php/odjava.php">Odjava</a> </span>
