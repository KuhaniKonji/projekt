<div>Prijavljeni ste kot <?php echo $ime_ucitelja; ?> (<a href="php/odjava.php">Odjava</a>) </div>
<div>Copyright 	&copy; Teo 2021 </div>
